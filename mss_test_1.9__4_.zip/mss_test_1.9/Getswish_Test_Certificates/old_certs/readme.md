# Old expired certificates #

This directory contains old expired certificates for reference purpose
only, they should no longer be used when communicating with the MSS
server.
